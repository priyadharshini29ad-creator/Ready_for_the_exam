package ready_for_the_exam;

import weka.core.SerializationHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Student {

    static class Question {
        int id;
        String text;
        String type;
        int marks;
        String concept;
        int frequency;

        Question(int id, String text, String type, int marks,
                 String concept, int frequency) {

            this.id = id;
            this.text = text;
            this.type = type;
            this.marks = marks;
            this.concept = concept;
            this.frequency = frequency;
        }
    }

    static String getConcept(String question) {

        question = question.toLowerCase();

        question = question.replace("?", "");
        question = question.replace(".", "");
        question = question.replace(",", "");
        question = question.replace(":", "");

        String[] words = question.split("\\s+");

        StringBuilder concept = new StringBuilder();

        for (String word : words) {

            if (word.equals("what") ||
                word.equals("is") ||
                word.equals("are") ||
                word.equals("a") ||
                word.equals("an") ||
                word.equals("the") ||
                word.equals("define") ||
                word.equals("explain") ||
                word.equals("describe") ||
                word.equals("discuss") ||
                word.equals("write") ||
                word.equals("about") ||
                word.equals("give") ||
                word.equals("mention") ||
                word.equals("state") ||
                word.equals("elaborate") ||
                word.equals("brief") ||
                word.equals("detailed") ||
                word.equals("note") ||
                word.equals("short") ||
                word.equals("long") ||
                word.equals("with") ||
                word.equals("example") ||
                word.equals("examples") ||
                word.equals("suitable") ||
                word.equals("relevant") ||
                word.equals("applications") ||
                word.equals("application") ||
                word.equals("on") ||
                word.equals("of") ||
                word.equals("in") ||
                word.equals("for") ||
                word.equals("and") ||
                word.equals("its") ||
                word.equals("their") ||
                word.equals("meant") ||
                word.equals("by")) {

                continue;
            }

            concept.append(word).append(" ");
        }

        return concept.toString().trim();
    }


    static List<Question> getQuestions(
            String subjectCode,
            int year) {

        List<Question> questions = new ArrayList<>();

        try {

            Connection con = DatabaseConnection.getConnection();

            String sql =
                "SELECT question_id, question_text, question_type, marks "
              + "FROM QUESTION "
              + "WHERE subject_code = ? AND year = ? "
              + "ORDER BY question_id";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, subjectCode);
            ps.setInt(2, year);

            ResultSet rs = ps.executeQuery();

            Map<String, Integer> frequencyMap = new HashMap<>();

            List<Question> temp = new ArrayList<>();

            while (rs.next()) {

                int id = rs.getInt("question_id");
                String text = rs.getString("question_text");
                String type = rs.getString("question_type");
                int marks = rs.getInt("marks");

                String concept = getConcept(text);

                if (concept.length() == 0) {
                    concept = text.toLowerCase();
                }

                temp.add(
                    new Question(
                        id,
                        text,
                        type,
                        marks,
                        concept,
                        0
                    )
                );

                frequencyMap.put(
                    concept,
                    frequencyMap.getOrDefault(concept, 0) + 1
                );
            }

            for (Question q : temp) {

                q.frequency = frequencyMap.get(q.concept);

                questions.add(q);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return questions;
    }


    static void showCategory(
            List<Question> questions,
            String category) {

        System.out.println();
        System.out.println("========================================");
        System.out.println(category);
        System.out.println("========================================");

        int count = 0;

        for (Question q : questions) {

            boolean show = false;

            if (category.equals("IMPORTANT QUESTIONS")
                    && q.frequency >= 3) {

                show = true;
            }

            else if (category.equals("MODERATELY IMPORTANT QUESTIONS")
                    && q.frequency == 2) {

                show = true;
            }

            else if (category.equals("LESS IMPORTANT QUESTIONS")
                    && q.frequency == 1) {

                show = true;
            }

            if (show) {

                count++;

                System.out.println(
                    count + ". " + q.text
                    + " [" + q.type + ", "
                    + q.marks + " marks]"
                );
            }
        }

        if (count == 0) {
            System.out.println("No questions found.");
        }

        System.out.println();
        System.out.println("Total Questions: " + count);
    }


    static void generateModelPaper(
            String subjectCode,
            int year,
            String examName) {

        List<Question> shortQuestions = new ArrayList<>();
        List<Question> longQuestions = new ArrayList<>();

        try {

            Connection con = DatabaseConnection.getConnection();

            String sql =
                "SELECT question_id, question_text, "
              + "question_type, marks "
              + "FROM QUESTION "
              + "WHERE subject_code = ? "
              + "AND year = ? "
              + "AND exam_name = ?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, subjectCode);
            ps.setInt(2, year);
            ps.setString(3, examName);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int id = rs.getInt("question_id");
                String text = rs.getString("question_text");
                String type = rs.getString("question_type");
                int marks = rs.getInt("marks");

                Question q =
                    new Question(
                        id,
                        text,
                        type,
                        marks,
                        "",
                        0
                    );

                if (marks == 2 ||
                    type.equalsIgnoreCase("SHORT")) {

                    shortQuestions.add(q);
                }

                else if (marks == 8 ||
                         type.equalsIgnoreCase("LONG")) {

                    longQuestions.add(q);
                }
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        Collections.shuffle(shortQuestions);
        Collections.shuffle(longQuestions);

        System.out.println();
        System.out.println("========================================");
        System.out.println("      AI GENERATED MODEL QUESTION PAPER");
        System.out.println("========================================");

        System.out.println("Subject : " + subjectCode);
        System.out.println("Year    : " + year);
        System.out.println("Exam    : " + examName);

        System.out.println("----------------------------------------");

        int questionNumber = 1;
        int totalMarks = 0;

        int shortCount =
            Math.min(5, shortQuestions.size());

        for (int i = 0; i < shortCount; i++) {

            Question q = shortQuestions.get(i);

            System.out.println(
                questionNumber + ". "
                + q.text
                + " - "
                + q.marks
                + " marks"
            );

            totalMarks += q.marks;
            questionNumber++;
        }

        if (longQuestions.size() > 0) {

            Question q = longQuestions.get(0);

            System.out.println(
                questionNumber + ". "
                + q.text
                + " - "
                + q.marks
                + " marks"
            );

            totalMarks += q.marks;
        }

        System.out.println("----------------------------------------");
        System.out.println("Total Marks: " + totalMarks);
        System.out.println("========================================");
    }


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Load final Weka model
        try {

            SerializationHelper.read(
                "question_importance1.model"
            );

            System.out.println("AI Model Loaded Successfully!");

        } catch (Exception e) {

            System.out.println("AI Model could not be loaded.");
            e.printStackTrace();
        }

        System.out.println();
        System.out.println("========================================");
        System.out.println("       AI QUESTION BANK SYSTEM");
        System.out.println("========================================");

        System.out.print("Enter Subject Code: ");
        String subjectCode = sc.nextLine().trim();

        System.out.print("Enter Year: ");
        int year = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Exam Name (CT1/CT2/CAT1/CAT2/SEM): ");
        String examName = sc.nextLine().trim();

        List<Question> questions =
            getQuestions(subjectCode, year);

        if (questions.size() == 0) {

            System.out.println();
            System.out.println("No questions found.");

            sc.close();
            return;
        }

        while (true) {

            System.out.println();
            System.out.println("========================================");
            System.out.println("              STUDENT MENU");
            System.out.println("========================================");

            System.out.println("1. Important Questions");
            System.out.println("2. Moderately Important Questions");
            System.out.println("3. Less Important Questions");
            System.out.println("4. Generate Model Question Paper");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();

            if (choice == 1) {

                showCategory(
                    questions,
                    "IMPORTANT QUESTIONS"
                );
            }

            else if (choice == 2) {

                showCategory(
                    questions,
                    "MODERATELY IMPORTANT QUESTIONS"
                );
            }

            else if (choice == 3) {

                showCategory(
                    questions,
                    "LESS IMPORTANT QUESTIONS"
                );
            }

            else if (choice == 4) {

                generateModelPaper(
                    subjectCode,
                    year,
                    examName
                );
            }

            else if (choice == 5) {

                System.out.println("Thank you!");
                break;
                
            }

            else {

                System.out.println("Invalid choice.");
            }
        }

        sc.close();
    }
}