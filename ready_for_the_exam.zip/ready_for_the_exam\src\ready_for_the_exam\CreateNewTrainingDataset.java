package ready_for_the_exam;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class CreateNewTrainingDataset {

    static String getConcept(String question) {

        question = question.toLowerCase();

        question = question.replace("?", "");
        question = question.replace(".", "");
        question = question.replace(",", "");

        String[] words = question.split("\\s+");

        StringBuilder concept = new StringBuilder();

        for (String word : words) {

            if (word.equals("what") ||
                word.equals("is") ||
                word.equals("are") ||
                word.equals("a") ||
                word.equals("an") ||
                word.equals("the") ||
                word.equals("define") ||
                word.equals("explain") ||
                word.equals("describe") ||
                word.equals("discuss") ||
                word.equals("write") ||
                word.equals("about") ||
                word.equals("give") ||
                word.equals("mention") ||
                word.equals("state") ||
                word.equals("elaborate") ||
                word.equals("brief") ||
                word.equals("detailed") ||
                word.equals("note") ||
                word.equals("short") ||
                word.equals("long") ||
                word.equals("with") ||
                word.equals("example") ||
                word.equals("examples") ||
                word.equals("suitable") ||
                word.equals("relevant") ||
                word.equals("applications") ||
                word.equals("application") ||
                word.equals("on") ||
                word.equals("of") ||
                word.equals("in") ||
                word.equals("for") ||
                word.equals("and") ||
                word.equals("its") ||
                word.equals("their")) {

                continue;
            }

            concept.append(word).append(" ");
        }

        return concept.toString().trim();
    }

    public static void main(String[] args) {

        try {

            Connection con = DatabaseConnection.getConnection();

            String sql = "SELECT question_id, subject_code, year, exam_name, "
                       + "question_text, question_type, marks "
                       + "FROM QUESTION "
                       + "ORDER BY question_id";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            Map<String, Integer> conceptCount = new HashMap<>();

            // Count each concept
            while (rs.next()) {

                String subject = rs.getString("subject_code");
                int year = rs.getInt("year");
                String question = rs.getString("question_text");

                String concept = getConcept(question);

                String key = subject + "|" + year + "|" + concept;

                if (conceptCount.containsKey(key)) {

                    conceptCount.put(
                        key,
                        conceptCount.get(key) + 1
                    );

                } else {

                    conceptCount.put(key, 1);
                }
            }

            rs.close();
            ps.close();

            String outputFile = "src/model/training_dataset_new.csv";

            FileWriter writer = new FileWriter(outputFile);

            writer.append(
                "question_id,subject,year,exam_name,"
                + "question_text,question_type,marks,"
                + "concept,frequency,similar_question_count,importance\n"
            );

            // Read questions again
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {

                int questionId = rs.getInt("question_id");

                String subject = rs.getString("subject_code");

                int year = rs.getInt("year");

                String exam = rs.getString("exam_name");

                String question = rs.getString("question_text");

                String type = rs.getString("question_type");

                int marks = rs.getInt("marks");

                String concept = getConcept(question);

                String key = subject + "|" + year + "|" + concept;

                int frequency = conceptCount.get(key);

                int similarQuestionCount = frequency - 1;

                String importance;

                if (frequency == 1) {

                    importance = "Less Important";

                } else if (frequency == 2) {

                    importance = "Moderately Important";

                } else {

                    importance = "Important";
                }

                // Escape quotes for CSV
                question = question.replace("\"", "\"\"");

                concept = concept.replace("\"", "\"\"");

                writer.append(String.valueOf(questionId)).append(",");
                writer.append(subject).append(",");
                writer.append(String.valueOf(year)).append(",");
                writer.append(exam).append(",");

                writer.append("\"")
                      .append(question)
                      .append("\",");

                writer.append(type).append(",");

                writer.append(String.valueOf(marks)).append(",");

                writer.append("\"")
                      .append(concept)
                      .append("\",");

                writer.append(String.valueOf(frequency)).append(",");

                writer.append(
                    String.valueOf(similarQuestionCount)
                ).append(",");

                writer.append(importance).append("\n");
            }

            writer.close();

            rs.close();
            ps.close();
            con.close();

            System.out.println();
            System.out.println(
                "New training dataset created successfully!"
            );

            System.out.println(
                "File: src/model/training_dataset_new.csv"
            );

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}