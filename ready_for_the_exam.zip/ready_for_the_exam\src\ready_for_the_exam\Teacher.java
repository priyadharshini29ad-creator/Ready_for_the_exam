
package ready_for_the_exam;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Teacher {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Subject Code: ");
        String subjectCode = sc.nextLine().trim();

        System.out.print("Enter Exam Name: ");
        String examName = sc.nextLine().trim();

        System.out.print("Enter Year: ");

        int year;

        while (true) {
            try {
                year = Integer.parseInt(sc.nextLine().trim());
                break;
            } catch (NumberFormatException e) {
                System.out.print("Enter a valid year: ");
            }
        }

        String choice;

        do {

            System.out.println();
            System.out.println("========================================");
            System.out.println("           TEACHER QUESTION INPUT");
            System.out.println("========================================");

            System.out.print("Enter Question: ");
            String questionText = sc.nextLine().trim();

            System.out.print("Enter Question Type (SHORT/LONG): ");
            String questionType = sc.nextLine().trim();

            while (!questionType.equalsIgnoreCase("SHORT")
                    && !questionType.equalsIgnoreCase("LONG")) {

                System.out.print("Enter only SHORT or LONG: ");
                questionType = sc.nextLine().trim();
            }

            System.out.print("Enter Marks: ");

            int marks;

            while (true) {
                try {
                    marks = Integer.parseInt(sc.nextLine().trim());
                    break;
                } catch (NumberFormatException e) {
                    System.out.print("Enter a valid number for marks: ");
                }
            }

            String sql =
                "INSERT INTO QUESTION " +
                "(subject_code, exam_name, year, question_text, " +
                "question_type, marks) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

            try {

                Connection con = DatabaseConnection.getConnection();

                PreparedStatement ps = con.prepareStatement(sql);

                ps.setString(1, subjectCode);
                ps.setString(2, examName);
                ps.setInt(3, year);
                ps.setString(4, questionText);
                ps.setString(5, questionType.toUpperCase());
                ps.setInt(6, marks);

                ps.executeUpdate();

                System.out.println();
                System.out.println("Question saved successfully!");

                ps.close();
                con.close();

            } catch (Exception e) {

                if (e.getMessage() != null
                        && e.getMessage().contains("ORA-00001")) {

                    System.out.println();
                    System.out.println("This question already exists!");

                } else {
                    e.printStackTrace();
                }
            }

            System.out.print("Add another question? (yes/no): ");
            choice = sc.nextLine().trim();

            while (!choice.equalsIgnoreCase("yes")
                    && !choice.equalsIgnoreCase("no")) {

                System.out.print("Please enter yes or no: ");
                choice = sc.nextLine().trim();
            }

        } while (choice.equalsIgnoreCase("yes"));

        System.out.println();
        System.out.println("Teacher input completed.");

        sc.close();
    }
}
